# PyPrankError
PyPrankError is a Python package that lets the user create silly (or serious) error messages, stack traces, crash reports, and hacked messages for a pranks purpose.

## Team members
1. [Nathalia Xu](https://github.com/slurp-slurp)
2. [Bobby Impastato](https://github.com/bobbyimpastato)
3. [Phoebus Yip](https://github.com/phoebusyip)
4. [Alicia Hwang](https://github.com/a-j-hwang)



## Instructions

TBD

